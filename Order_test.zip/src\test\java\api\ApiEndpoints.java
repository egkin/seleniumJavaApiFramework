package api;

public class ApiEndpoints {
    public static final String BASE_URL = "https://webhook.site/";
    public static final String LOGIN_INFORMATION = BASE_URL+"28358e56-6aff-4c31-b4dd-577e45a9f2bf";
    public static final String PRICE_UPDATE = BASE_URL+"f6b523fc-a706-4704-8215-55ed5e5a83c9";
}
